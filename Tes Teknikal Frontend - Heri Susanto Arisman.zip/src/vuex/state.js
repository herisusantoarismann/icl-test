const states = {
  isAuthenticate: false,
  token: null,
};

export default states;
